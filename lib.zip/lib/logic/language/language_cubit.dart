import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// Backs the Language selection screen and drives the app-wide locale +
/// text direction. Provided at the app root (see app.dart) so switching
/// language here actually re-skins the whole app immediately — it no
/// longer just pops back to Settings with no visible effect.
///
/// NOTE: this switches locale/direction only. Translating every screen's
/// hardcoded English strings into Arabic is a separate, larger task
/// (normally done with Flutter's arb-based localization) — ask if you'd
/// like that done next.
class LanguageCubit extends Cubit<String> {
  LanguageCubit() : super('English');

  static const List<String> available = [
    'English',
    'العربية (Arabic)',
  ];

  void select(String language) => emit(language);

  static Locale localeFor(String language) =>
      language == 'العربية (Arabic)' ? const Locale('ar') : const Locale('en');

  static TextDirection directionFor(String language) =>
      language == 'العربية (Arabic)' ? TextDirection.rtl : TextDirection.ltr;
}
