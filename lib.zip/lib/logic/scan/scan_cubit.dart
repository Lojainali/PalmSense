import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../data/mock/mock_data.dart';
import 'scan_state.dart';

/// Drives the CameraScreen capture flow. There's no real ML backend yet,
/// so [capture] and [pickFromGallery] just simulate an "Analyzing..." delay
/// before emitting a mock detection result that ResultsScreen renders.
class ScanCubit extends Cubit<ScanState> {
  ScanCubit() : super(const ScanState());

  final ImagePicker _picker = ImagePicker();

  Future<void> capture() async {
    emit(state.copyWith(status: ScanStatus.analyzing));
    await Future.delayed(const Duration(seconds: 2));
    final result = MockData.simulateDetection();
    emit(state.copyWith(status: ScanStatus.success, result: result));
  }

  /// Lets the user pick a leaf photo from their gallery instead of using
  /// the live camera. Does nothing if they back out of the picker.
  Future<void> pickFromGallery() async {
    final XFile? picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    emit(state.copyWith(status: ScanStatus.analyzing));
    await Future.delayed(const Duration(seconds: 2));
    final result = MockData.simulateDetection();
    emit(state.copyWith(status: ScanStatus.success, result: result));
  }

  void reset() => emit(const ScanState());
}
